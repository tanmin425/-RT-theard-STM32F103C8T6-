# RT-Thread 系统集成 - 遥控器

本项目已经从FreeRTOS迁移到RT-Thread实时操作系统。

## 文件结构

- `RT-Thread/src` - RT-Thread内核源代码
- `RT-Thread/include` - RT-Thread头文件
- `Core/Src/rtthread.c` - 线程定义和初始化
- `Core/Inc/rtthread.h` - 线程声明和接口
- `Core/Inc/rtconfig.h` - RT-Thread配置文件

## 移植步骤

1. 添加RT-Thread源文件到项目中
2. 创建rtthread.c和rtthread.h替代原来的freertos.c
3. 创建rtconfig.h配置文件
4. 修改main.c中的初始化代码

## 线程列表

- defaultTask - 默认线程
- Menu_task - 菜单控制线程
- NRF_task - 无线通信线程

## 配置MDK

请按照`rtconfig_setup.txt`中的步骤配置MDK项目。

## 注意事项

- RT-Thread与FreeRTOS的API有区别，主要体现在线程创建和延时函数上
- RT-Thread的优先级体系与FreeRTOS不同，数值越小优先级越高
- 部分FreeRTOS特有功能可能需要使用RT-Thread替代实现 